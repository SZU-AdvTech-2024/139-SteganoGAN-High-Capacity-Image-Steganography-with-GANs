=======
Credits
=======

Contributors
----------------

* Kevin Zhang <kevz@mit.edu> (Development lead)
* Plamen Valentinov <plamen@pythiac.com>
* Carles Sala <csala@csail.mit.edu>
* Kalyan Veeramachaneni <kalyan@mit.edu>


