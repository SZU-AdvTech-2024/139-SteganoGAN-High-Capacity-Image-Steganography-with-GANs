* SteganoGAN version or git commit:
* Python version (output of `python --version`):
* Pip version (output of `pip --version`):
* PyTorch version (output of `python -c "import torch; print(torch.__version__)"`):
* Operating System:

### Description

Describe what you were trying to get done.
Tell us what happened, what went wrong, and what you expected to happen.

### What I Did

```
Paste (all) the command(s) you ran and the output.
If there was a crash, please include the traceback here.
```
